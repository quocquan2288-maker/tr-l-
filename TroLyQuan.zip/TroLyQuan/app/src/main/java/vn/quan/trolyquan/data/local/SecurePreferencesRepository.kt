package vn.quan.trolyquan.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import vn.quan.trolyquan.domain.model.ActionExecutionResult
import vn.quan.trolyquan.domain.model.AiProviderType
import vn.quan.trolyquan.domain.model.AiSettings
import vn.quan.trolyquan.domain.model.ChatMessage
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.MessageSender
import vn.quan.trolyquan.domain.model.SystemCommand

/**
 * Lưu trữ bảo mật API Key bằng EncryptedSharedPreferences (mã hóa AES-256-GCM bởi Android Keystore)
 * và lưu trữ lịch sử hội thoại để Quân nhớ ngữ cảnh xuyên suốt giữa các lần mở app.
 */
class SecurePreferencesRepository(context: Context) {

    private val appContext = context.applicationContext

    private val encryptedPrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback an toàn trên một số ROM tùy biến lỗi Keystore phần cứng
            appContext.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun loadSettings(): AiSettings {
        val providerName = encryptedPrefs.getString(KEY_PROVIDER, AiProviderType.GEMINI.name)
            ?: AiProviderType.GEMINI.name
        val provider = try {
            AiProviderType.valueOf(providerName)
        } catch (_: Exception) {
            AiProviderType.GEMINI
        }

        val apiKey = encryptedPrefs.getString(KEY_API_KEY, vn.quan.trolyquan.domain.model.DefaultApiKeyConfig.PRECONFIGURED_GEMINI_KEY)
            ?.takeIf { it.isNotBlank() } ?: vn.quan.trolyquan.domain.model.DefaultApiKeyConfig.PRECONFIGURED_GEMINI_KEY
        val baseUrl = encryptedPrefs.getString(KEY_BASE_URL, provider.defaultBaseUrl)
            ?.takeIf { it.isNotBlank() } ?: provider.defaultBaseUrl
        val modelName = encryptedPrefs.getString(KEY_MODEL_NAME, provider.defaultModel)
            ?.takeIf { it.isNotBlank() } ?: provider.defaultModel

        return AiSettings(
            provider = provider,
            apiKey = apiKey.trim(),
            baseUrl = baseUrl.trim(),
            modelName = modelName.trim(),
            voiceAutoSpeak = encryptedPrefs.getBoolean(KEY_VOICE_AUTO_SPEAK, true),
            voicePitch = encryptedPrefs.getFloat(KEY_VOICE_PITCH, 0.90f),
            voiceRate = encryptedPrefs.getFloat(KEY_VOICE_RATE, 1.05f),
            preferredVoiceName = encryptedPrefs.getString(KEY_PREFERRED_VOICE, "") ?: "",
            continuousListenAfterSpeak = encryptedPrefs.getBoolean(KEY_CONTINUOUS_LISTEN, false),
            allowSlangAndRoast = encryptedPrefs.getBoolean(KEY_ALLOW_ROAST, true)
        )
    }

    fun saveSettings(settings: AiSettings) {
        encryptedPrefs.edit()
            .putString(KEY_PROVIDER, settings.provider.name)
            .putString(KEY_API_KEY, settings.apiKey.trim())
            .putString(KEY_BASE_URL, settings.baseUrl.trim())
            .putString(KEY_MODEL_NAME, settings.modelName.trim())
            .putBoolean(KEY_VOICE_AUTO_SPEAK, settings.voiceAutoSpeak)
            .putFloat(KEY_VOICE_PITCH, settings.voicePitch.coerceIn(0.5f, 1.6f))
            .putFloat(KEY_VOICE_RATE, settings.voiceRate.coerceIn(0.6f, 1.8f))
            .putString(KEY_PREFERRED_VOICE, settings.preferredVoiceName)
            .putBoolean(KEY_CONTINUOUS_LISTEN, settings.continuousListenAfterSpeak)
            .putBoolean(KEY_ALLOW_ROAST, settings.allowSlangAndRoast)
            .apply()
    }

    fun saveChatHistory(messages: List<ChatMessage>) {
        val recentMessages = messages.takeLast(MAX_SAVED_MESSAGES)
        val jsonArray = JSONArray()
        for (msg in recentMessages) {
            val obj = JSONObject().apply {
                put("id", msg.id)
                put("sender", msg.sender.name)
                put("text", msg.text)
                put("moodTag", msg.moodTag)
                put("timestampMillis", msg.timestampMillis)
                msg.executionResult?.let { res ->
                    val resObj = JSONObject().apply {
                        put("success", res.success)
                        put("commandType", res.commandType.name)
                        put("summaryTitle", res.summaryTitle)
                        put("detailMessage", res.detailMessage)
                    }
                    put("executionResult", resObj)
                }
            }
            jsonArray.put(obj)
        }
        encryptedPrefs.edit().putString(KEY_CHAT_HISTORY, jsonArray.toString()).apply()
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = encryptedPrefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val result = mutableListOf<ChatMessage>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val sender = try {
                    MessageSender.valueOf(obj.optString("sender", "QUAN"))
                } catch (_: Exception) {
                    MessageSender.QUAN
                }
                val execObj = obj.optJSONObject("executionResult")
                val execResult = if (execObj != null) {
                    val cmdType = try {
                        CommandType.valueOf(execObj.optString("commandType", "NONE"))
                    } catch (_: Exception) {
                        CommandType.NONE
                    }
                    ActionExecutionResult(
                        success = execObj.optBoolean("success", false),
                        commandType = cmdType,
                        summaryTitle = execObj.optString("summaryTitle", ""),
                        detailMessage = execObj.optString("detailMessage", "")
                    )
                } else null

                result.add(
                    ChatMessage(
                        id = obj.optString("id", i.toString()),
                        sender = sender,
                        text = obj.optString("text", ""),
                        moodTag = obj.optString("moodTag", "THANG_THAN"),
                        command = null,
                        executionResult = execResult,
                        timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis())
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearChatHistory() {
        encryptedPrefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }

    companion object {
        private const val PREFS_FILE_NAME = "quan_secure_prefs"
        private const val FALLBACK_PREFS_NAME = "quan_fallback_prefs"
        private const val KEY_PROVIDER = "ai_provider"
        private const val KEY_API_KEY = "ai_api_key"
        private const val KEY_BASE_URL = "ai_base_url"
        private const val KEY_MODEL_NAME = "ai_model_name"
        private const val KEY_VOICE_AUTO_SPEAK = "voice_auto_speak"
        private const val KEY_VOICE_PITCH = "voice_pitch"
        private const val KEY_VOICE_RATE = "voice_rate"
        private const val KEY_PREFERRED_VOICE = "preferred_voice_name"
        private const val KEY_CONTINUOUS_LISTEN = "continuous_listen"
        private const val KEY_ALLOW_ROAST = "allow_roast"
        private const val KEY_CHAT_HISTORY = "saved_chat_history_json"
        private const val MAX_SAVED_MESSAGES = 60
    }
}
