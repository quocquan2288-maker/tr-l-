@echo off
echo ==========================================================
echo    XAY DUNG APK TRO LY QUAN (KOTLIN + JETPACK COMPOSE)
echo ==========================================================

if exist gradlew.bat (
    call gradlew.bat assembleDebug
) else (
    gradle assembleDebug
)

if exist "app\build\outputs\apk\debug\app-debug.apk" (
    copy /Y "app\build\outputs\apk\debug\app-debug.apk" "TroLyQuan-v1.0-debug.apk"
    echo [THANH CONG] File APK da duoc tao tai: TroLyQuan-v1.0-debug.apk
)
pause
